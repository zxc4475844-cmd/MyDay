# My Day — Android widget

A simple weekly planner with a home-screen widget and tappable task checkboxes.

## Build
GitHub Actions builds a debug APK on every push to `main` and when manually started:
1. Open the **Actions** tab.
2. Select **Build My Day APK**.
3. Press **Run workflow** if it has not started automatically.
4. Open the completed run and download the `MyDay-APK` artifact.

## Install
Download and extract the artifact, then open `app-debug.apk` on the Android phone.
Android may ask you to allow installation from the browser or file manager.
After installation, long-press the home screen → Widgets → My Day.

## Notes
- This is a starter version. Schedule items are sample defaults based on the supplied weekly routine.
- The widget saves checkmarks for the current date and resets the visible completion state on the next date.
- The app is not signed for Play Store distribution; GitHub Actions creates a debug APK for personal testing.
