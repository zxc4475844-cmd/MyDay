package com.example.myday

import android.app.Activity
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.view.Gravity
import android.graphics.Color
import android.content.Intent
import android.appwidget.AppWidgetManager
import android.content.ComponentName

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(23, 25, 35))
        }
        fun line(text: String, size: Float, color: Int, bold: Boolean = false) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = size
                setTextColor(color)
                if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
                setPadding(0, 8, 0, 8)
            })
        }
        line("MY DAY", 28f, Color.WHITE, true)
        line("Твой план на каждый день", 16f, Color.LTGRAY)
        line("Добавь виджет на главный экран:", 18f, Color.WHITE, true)
        line("1. Зажми пустое место на рабочем столе Samsung.\n2. Выбери «Виджеты».\n3. Найди My Day и добавь его.\n4. Отмечай задачи прямо в виджете.", 15f, Color.LTGRAY)
        line("Расписание меняется автоматически по дням недели. Отмеченные задачи сохраняются до следующего дня.", 14f, Color.rgb(170, 180, 200))
        setContentView(root)
    }
}
