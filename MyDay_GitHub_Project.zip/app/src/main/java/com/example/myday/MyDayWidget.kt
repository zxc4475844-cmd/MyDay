package com.example.myday

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class Task(val time: String, val title: String, val id: String)

class MyDayWidget : AppWidgetProvider() {
    companion object {
        const val ACTION_TOGGLE = "com.example.myday.TOGGLE_TASK"

        private fun tasksForToday(): List<Task> {
            val day = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
            val tasks = mutableListOf<Task>()
            tasks += Task("Утро", "Завтрак и креатин", "creatine")
            if (day in Calendar.MONDAY..Calendar.FRIDAY) {
                tasks += Task("08:30–14:00", "Школа", "school")
            }
            when (day) {
                Calendar.MONDAY -> {
                    tasks += Task("16:00", "Подготовка: профильная математика", "study_math")
                    tasks += Task("20:00", "Тренировка", "workout")
                }
                Calendar.TUESDAY -> tasks += Task("16:00", "Подготовка: физика", "study_physics")
                Calendar.WEDNESDAY -> {
                    tasks += Task("16:00", "Подготовка: русский язык", "study_russian")
                    tasks += Task("20:00", "Тренировка", "workout")
                }
                Calendar.THURSDAY -> tasks += Task("16:00", "Математика и физика", "study_mix")
                Calendar.FRIDAY -> {
                    tasks += Task("15:40", "Тренировка", "workout")
                    tasks += Task("17:00–03:00", "Работа", "work")
                }
                Calendar.SATURDAY -> {
                    tasks += Task("11:00–15:00", "Физика", "physics_class")
                    tasks += Task("16:30", "Работа", "work")
                }
                Calendar.SUNDAY -> {
                    tasks += Task("12:00", "Задания второй части математики", "study_exam")
                    tasks += Task("16:00–23:00", "Работа", "work")
                }
            }
            tasks += Task("Каждый день", "Чтение — 30 минут", "reading")
            return tasks
        }


    }

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateWidget(context, manager, it) }
    }

    private fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
        val prefs = context.getSharedPreferences("myday", Context.MODE_PRIVATE)
        val views = RemoteViews(context.packageName, R.layout.widget)
        val tasks = tasksForToday()
        val date = dateKey()
        val doneCount = tasks.count { prefs.getBoolean("$date:${it.id}", false) }
        val dayName = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
        views.setTextViewText(R.id.widget_day, dayName.replaceFirstChar { it.uppercase() })
        views.setTextViewText(R.id.widget_progress, "$doneCount из ${tasks.size} выполнено")
        views.removeAllViews(R.id.task_list)

        tasks.forEachIndexed { index, task ->
            val done = prefs.getBoolean("$date:${task.id}", false)
            val row = RemoteViews(context.packageName, R.layout.widget_task)
            row.setTextViewText(R.id.task_check, if (done) "☑" else "□")
            row.setTextViewText(R.id.task_time, task.time)
            row.setTextViewText(R.id.task_title, task.title)
            val intent = Intent(context, MyDayWidget::class.java).apply {
                action = ACTION_TOGGLE
                putExtra("task_id", task.id)
            }
            val pending = PendingIntent.getBroadcast(
                context, id * 1000 + index, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            row.setOnClickPendingIntent(R.id.task_row, pending)
            views.addView(R.id.task_list, row)
        }
        val launch = PendingIntent.getActivity(
            context, 0, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        views.setOnClickPendingIntent(R.id.widget_header, launch)
        manager.updateAppWidget(id, views)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ACTION_TOGGLE) {
            val taskId = intent.getStringExtra("task_id") ?: return
            val prefs = context.getSharedPreferences("myday", Context.MODE_PRIVATE)
            val key = "${dateKey()}:$taskId"
            prefs.edit().putBoolean(key, !prefs.getBoolean(key, false)).apply()
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, MyDayWidget::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }
    }

    private fun dateKey(): String =
        SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
}
